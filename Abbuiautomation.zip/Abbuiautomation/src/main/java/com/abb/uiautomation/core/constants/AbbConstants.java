package com.abb.uiautomation.core.constants;

public interface AbbConstants {
	
	int COL_TESTCASE_ID = 0;
	String EMPTY_STR =""; 

}
