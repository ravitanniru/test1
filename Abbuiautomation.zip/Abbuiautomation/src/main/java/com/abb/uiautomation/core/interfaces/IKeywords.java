package com.abb.uiautomation.core.interfaces;

import org.openqa.selenium.WebDriver;

public interface IKeywords {
	
	//void navigate();

	void inputText(WebDriver driver,String locatorType, String locatorValue, String testData);
	
	void click(WebDriver driver,String locatorType, String locatorValue, String testData);
	
	void VerifyElementExist(WebDriver driver,String locatorType, String locatorValue,String testData);

	void navigate(WebDriver driver,String locatorType, String locatorValue, String testData);
	
	void select(WebDriver driver,String locatorType, String locatorValue,String testData);
}
