package com.abb.uiautomation.core.services;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.utils.EventExecutor;
import com.abb.uiautomation.core.utils.ByObjectUtils;

public class keywordService implements IKeywords {
	
	WebDriver driver;
	
	public keywordService(WebDriver driver) {
		this.driver = driver;
	}
	
	public keywordService() {
		
	}
	
	public void keywordExecute(WebDriver driver,String keyWord,String locatorType, String locatorValue, String testData)
	{
		System.out.println("Keyword :" + keyWord);
		switch (keyWord.toLowerCase())
		{
		case "navigate" :
			{
				navigate(driver,locatorType,locatorValue,testData);
				break;
			}
		case "entertext":
			{
				inputText(driver,locatorType,locatorValue,testData);
				break;
			}
		case "click":
		{
				click(driver,locatorType,locatorValue,testData);
				break;
		}
		case "verifyelementexist" :
		{
				VerifyElementExist(driver,locatorType,locatorValue,testData);
				break;
		}
		case "select" :
		{
			select(driver,locatorType,locatorValue,testData);
		}
		}
	}

	public void navigate(WebDriver driver,String locatorType, String locatorValue, String testData) {
		
		driver.get(testData);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	@Override
	public void inputText(WebDriver driver,String locatorType, String locatorValue, String testData) {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		By element = ByObjectUtils.getByObject(locatorType, locatorValue);
		EventExecutor.enterText(driver, element, testData);
	}

	@Override
	public void click(WebDriver driver,String locatorType, String locatorValue,String testData) {
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		By element = ByObjectUtils.getByObject(locatorType, locatorValue);
		EventExecutor.click(driver,element);
		
	}

	@Override
	public void VerifyElementExist(WebDriver driver,String locatorType, String locatorValue,String testData) {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		By element = ByObjectUtils.getByObject(locatorType, locatorValue);
		System.out.println ("in verify ecist");
		boolean status = EventExecutor.isElementExist(driver, element);
		System.out.println ("boolean  : "+ status);
	}
	
	@Override
	public void select(WebDriver driver,String locatorType, String locatorValue,String testData) {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		By element = ByObjectUtils.getByObject(locatorType, locatorValue);
		EventExecutor.enterText(driver, element, testData);
	}

}

