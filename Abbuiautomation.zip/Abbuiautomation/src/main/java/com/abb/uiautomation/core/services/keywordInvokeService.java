package com.abb.uiautomation.core.services;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.utils.XlsxFileUtils;

public class keywordInvokeService {
	
	IKeywords keywords;
	XlsxFileUtils xlsxfileutils = new XlsxFileUtils();
	XSSFWorkbook workBook = new XSSFWorkbook();
	keywordService keywordservice = new keywordService();
	
	public keywordInvokeService(IKeywords keywords) {
		this.keywords = keywords;	
	}
	
	public void execute(String filePath) throws Exception{
		runTestStep(filePath);
	}

	public boolean runTestStep(String filePath) throws Exception{
		xlsxfileutils.setExcelFile(filePath);
		workBook = xlsxfileutils.getWorkBook();
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\INRAKUM106\\abbUIAutomation\\Abbuiautomation\\TestResources\\Testdepends\\chromedriver.exe");
				
		WebDriver driver = new ChromeDriver();
		System.out.println("xlsxfileutils.getRowCount : " + xlsxfileutils.getRowCount("TestSuite"));
		for (int tcase=1; tcase < xlsxfileutils.getRowCount("TestSuite"); tcase++)
		{
			String testcaseId = xlsxfileutils.getCellData(tcase, 1, "TestSuite");
			String testcaseName = xlsxfileutils.getCellData(tcase, 2, "TestSuite");
			String testcaseDesc = xlsxfileutils.getCellData(tcase, 3, "TestSuite");
			String execute = xlsxfileutils.getCellData(tcase, 4, "TestSuite");
			System.out.print(" testcaseId : " + testcaseId);
			System.out.print(" testcaseName : " + testcaseName);
			System.out.print(" testcaseDesc : " + testcaseDesc);
			System.out.println(" execute : " + execute);
			if (execute.equalsIgnoreCase("yes"))
			{
				for (int tstep=1; tstep< xlsxfileutils.getRowCount(testcaseName); tstep++)
				{
					String keyword = xlsxfileutils.getCellData(tstep, 3, testcaseName);
					String locatortype = xlsxfileutils.getCellData(tstep, 4, testcaseName);
					String locatorvalue	= xlsxfileutils.getCellData(tstep, 5, testcaseName);
					String testdata =  xlsxfileutils.getCellData(tstep, 6, testcaseName);
					System.out.print("keyword " + keyword);
					System.out.print("  locatortype "+locatortype);
					System.out.print("  locatorvalue " +locatorvalue);
					System.out.println("  testdata " + testdata);	
					keywordservice.keywordExecute(driver, keyword, locatortype, locatorvalue, testdata);
					
				}
			}			
		}
		return false;
	}
}
