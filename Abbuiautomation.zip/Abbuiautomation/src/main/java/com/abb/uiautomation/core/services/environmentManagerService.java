package com.abb.uiautomation.core.services;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class environmentManagerService {
	
	private static Properties properties;
	
	/*
	 *This is method to get the column name of s.no from config properties file
	 */
	public static String getSerialNumberColumn() { return properties.getProperty("S.NO");  }
	
	/*
	 *This is method to get the column name of Test case id  from config properties file
	 */

	public static String getTestCaseIdColumn() { return properties.getProperty("TestCaseID"); }

	/*
	 *This is method to get the column name of Test case name from config properties file
	 */
	public static String getTestCaseNameColumn() { return properties.getProperty("TestCaseName"); }
	
	/*
	 *This is method to get the column name of Execute from config properties file
	 */
	public static String getExecuteColumn() { return properties.getProperty("Execute"); }
	
	/*
	 *This is method to get the column name of Test step id  from config properties file
	 */

	public static String getTestStepIdColumn() { return properties.getProperty("TestStepID"); }
	
	/*
	 *This is method to get the column name of Test step Description  from config properties file
	 */

	public static String getTestStepDescriptionColumn() { return properties.getProperty("TeststepDescription"); }
	
	/*
	 *This is method to get the column name of Test step keyword  from config properties file
	 */

	public static String getTestStepkeywordColumn() { return properties.getProperty("keyword"); }
	
	/*
	 *This is method to get the column name of Test step Locator Type  from config properties file
	 */

	public static String getTestStepLocatorTypeColumn() { return properties.getProperty("LocatorType"); }
	
	/*
	 *This is method to get the column name of Test step Locator Value  from config properties file
	 */

	public static String getTestStepLocatorValueColumn() { return properties.getProperty("LocatorValue"); }
	
	/*
	 *This is method to get the column name of Test step Expected Result  from config properties file
	 */

	public static String getTestStepTestDataColumn() { return properties.getProperty("TestData"); }
	
	/*
	 *This is method to get the column name of Test step Expected Result  from config properties file
	 */

	public static String getTestStepExpectedResultColumn() { return properties.getProperty("ExpectedResult"); }
	
	/*
	 * Static block to initializing the properties method
	 */
	static {
		properties = new Properties();

		try {
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\config.properties");

			//FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"/src/main/resources/config.properties");

			properties.load(ip);

		} catch (IOException e) {
			String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
		}
	}
}
