package com.abb.uiautomation.core.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.abb.uiautomation.core.constants.AbbConstants;

public class XlsxFileUtils {
	private static Logger log = Logger.getLogger(XlsxFileUtils.class.getName());

	private XSSFSheet xssfSheet;
	private XSSFWorkbook xssfWorkBook;
	private Cell cell;
	private XSSFRow row;
	private String filePath;

	public XSSFWorkbook getWorkBook() {
	return xssfWorkBook;
	}

	/**
	* Set's the path of .xlsx file
	*
	* @param filePath
	* @throws Exception
	*/
	public void setExcelFile(final String filePath) throws Exception {
		this.filePath = filePath.replace("\\u0020", "%20");
		System.out.println(this.filePath);
		FileInputStream ExcelFile = new FileInputStream(this.filePath);
		xssfWorkBook = new XSSFWorkbook(ExcelFile);
	}


	/**
	* Return's the cell data
	*
	* @param excelWBook
	* @param RowNum
	* @param ColNum
	* @param SheetName
	* @return
	* @throws Exception
	*/
	public String getCellData(final XSSFWorkbook excelWBook, final int RowNum, final int ColNum, final String SheetName)
	throws Exception {
	try {
		xssfSheet = excelWBook.getSheet(SheetName);
		System.out.println(xssfSheet);
		cell = xssfSheet.getRow(RowNum).getCell(ColNum);
		System.out.println(cell);
		String CellData = cell.getStringCellValue();
		System.out.println(CellData);
		return CellData;
	} catch (Exception e) {
		log.error("An exception occured: " + e.getMessage());
	return "";
	}
	}

	/**
	* Return's the cell data
	*
	* @param RowNum
	* @param ColNum
	* @param SheetName
	* @return
	* @throws Exception
	*/
	public String getCellData(final int RowNum, final int ColNum, final String SheetName) throws Exception {
	try {
	if (xssfWorkBook != null) {
		xssfSheet = xssfWorkBook.getSheet(SheetName);
		if (xssfSheet != null && xssfSheet.getRow(RowNum) != null) {
		cell = xssfSheet.getRow(RowNum).getCell(ColNum);
		if (cell != null) {
		if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
		cell.setCellType(Cell.CELL_TYPE_STRING);
		return cell.getStringCellValue();
	}
	return cell.getStringCellValue();
	}
	}
	}

	} catch (Exception e) {
		log.error("An exception occured: " + e.getMessage());
		e.printStackTrace();
	}

	return AbbConstants.EMPTY_STR;
	}

	/**
	* Return's the row length
	*
	* @param SheetName
	* @return
	*/
	public int getRowCount(final String SheetName) {
		xssfSheet = xssfWorkBook.getSheet(SheetName);
		if (xssfSheet != null) {
			return xssfSheet.getLastRowNum() + 1;
		}
		return 0;
		}

	public int getRowContains(final String sTestCaseName, final int colNum, final String SheetName) throws Exception {
		int iRowNum = 0;
		try {
				int rowCount = this.getRowCount(SheetName);
				for (; iRowNum < rowCount; iRowNum++) {
					if (this.getCellData(iRowNum, colNum, SheetName).equalsIgnoreCase(sTestCaseName)) {
						break;
					}
				}
		} catch (Exception e) {
			log.error("An exception occured: " + e.getMessage());
		}
		return iRowNum;
	}

	public int getTestStepsCount(final String SheetName, final String sTestCaseID, final int iTestCaseStart)
	throws Exception {
		try {
			for (int i = iTestCaseStart; i <= this.getRowCount(SheetName); i++) {
				if (!sTestCaseID.equals(this.getCellData(i, AbbConstants.COL_TESTCASE_ID, SheetName))) {
					int number = i;
					return number;
				}
			}
			xssfSheet = xssfWorkBook.getSheet(SheetName);
			int number = xssfSheet.getLastRowNum() + 1;
			return number;
		} catch (Exception e) {
			log.error("An exception occured: " + e.getMessage());
			return 0;
		}
	}

	/**
	* Set's the data into the cell
	*
	* @param filePath
	* @param Result
	* @param rowNum
	* @param colNum
	* @param sheetName
	* @throws Exception
	*/
	public void setCellData(final String filePath, final String Result, final int rowNum, final int colNum,
	final String sheetName) throws Exception {

		log.info("SetCellData being called");
	
		FileOutputStream outputStream = null;
		FileInputStream inputStream = null;

		try {
			inputStream = new FileInputStream(filePath);
			xssfSheet = xssfWorkBook.getSheet(sheetName);
			row = xssfSheet.getRow(rowNum);
			cell = row.getCell(colNum, XSSFRow.RETURN_BLANK_AS_NULL);
			if (cell == null) {
				cell = row.createCell(colNum);
				cell.setCellValue(Result);
			} else {
				cell.setCellValue(Result);
			}
			log.info("Cell is updated!");
			outputStream = new FileOutputStream(filePath);
			xssfWorkBook.write(outputStream);
			xssfWorkBook = new XSSFWorkbook(inputStream);
		} catch (Exception e) {
			log.error("Failed to set data into the cell: " + e.getMessage());
		} finally {
			//FileUtils.close(outputStream);
			//FileUtils.close(inputStream);
				outputStream.close();
				inputStream.close();
	}
	}

	/**
	* Set's the data into the cell
	*
	* @param xpath
	* @param rowNum
	* @param colNum
	* @param sheetName
	* @throws Exception
	*/
	public void setCellData(final String xpath, final int rowNum, final int colNum, final String sheetName)
	throws Exception {

		log.info("SetCellData being called");

		FileOutputStream outputStream = null;

	try {
		xssfSheet = xssfWorkBook.getSheet(sheetName);
		row = xssfSheet.getRow(rowNum);
		cell = row.getCell(colNum, XSSFRow.RETURN_BLANK_AS_NULL);
		if (cell == null) {
			cell = row.createCell(colNum);
			cell.setCellValue(xpath);
		} else {
			cell.setCellValue(xpath);
		}
		log.info("Cell is updated!");
		outputStream = new FileOutputStream(filePath);
		xssfWorkBook.write(outputStream);
		} catch (Exception e) {
			log.error("Failed to set data into the cell: " + e.getMessage());
		} finally {
			//FileUtils.close(outputStream);
		outputStream.close();
		}
	}
}
